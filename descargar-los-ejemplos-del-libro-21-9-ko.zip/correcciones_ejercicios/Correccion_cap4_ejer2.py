__author__ = 'febel'
n=10
resultado=0
while n!=0:
    resultado=resultado+n
    n=n-1
print(resultado)
resultado=0
for n in range(1,11):
    resultado=resultado+n
print(resultado)