__author__ = 'febel'
a=1
while a <= 10:
    if a%2==0:
        print(a)
    a=a+1