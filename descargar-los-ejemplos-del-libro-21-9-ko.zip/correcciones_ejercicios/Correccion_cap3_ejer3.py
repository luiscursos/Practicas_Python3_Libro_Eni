__author__ = 'febel'
edad=10
c_edad=""
edad=int(input("Edad :"))
if edad >= 12:
    print("Cadete")
elif edad >= 10:
    print("Infantil")
elif edad >= 8:
    print("Alev�n")
elif edad >= 6:
    print("Benjam�n")