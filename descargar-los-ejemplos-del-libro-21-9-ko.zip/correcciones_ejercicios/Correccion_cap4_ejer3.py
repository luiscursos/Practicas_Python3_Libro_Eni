__author__ = 'febel'
a=3
b=7
resultado=0
while b != 0:
    resultado=resultado+a
    b=b-1
print(resultado)
