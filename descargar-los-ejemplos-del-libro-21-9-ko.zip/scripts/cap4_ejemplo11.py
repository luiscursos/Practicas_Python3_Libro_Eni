__author__ = 'febel'
Cnt=int(input("¿Qué factorial?\n"))
resultado=1
for i in range(2,Cnt+1):
    resultado=resultado*i
print(resultado)
