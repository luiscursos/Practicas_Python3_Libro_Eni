_author__ = 'febel'
resultado=1
tabla=int(input("¿tabla?\n"))
Cnt=1
while Cnt<=10:
  resultado=tabla*Cnt
  print(str(tabla)+" x "+str(Cnt)+" = "+str(resultado))
  Cnt=Cnt+1
