__author__ = 'febel'

txt1 = " Hola amigos "
txt1 = txt1.replace(" ", "")  # elimina los espacios
valor = len(txt1)  # longitud = 14
print(txt1, " de longitud ", valor)

txt2 = txt1[3:5]
print(txt2)
