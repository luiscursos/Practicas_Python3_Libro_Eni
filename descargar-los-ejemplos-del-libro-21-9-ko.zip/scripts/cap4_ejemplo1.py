__author__ = 'febel'
resultado=1
tabla=int(input("�tabla?\n"))
cont=1
while cont<=10 :
    resultado=tabla*cont
    print(tabla," x ",cont," = ",resultado)
    cont=cont+1