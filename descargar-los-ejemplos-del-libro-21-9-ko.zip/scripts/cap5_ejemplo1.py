__author__ = 'febel'
t=[2,7,9,10,11,14,17,18,20,22]
copia=t
print(t[2])
copia[2]=5
print(t[2])
