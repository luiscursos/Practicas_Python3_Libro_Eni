tabla=1 
Cnt=0 
while tabla <= 10: 
    print("Tabla del ",tabla) 
    Cnt=1 
    while Cnt <= 10: 
        resultado=Cnt*tabla 
        print(tabla,"x",Cnt,"=",resultado) 
        Cnt=Cnt+1 
    tabla=tabla+1
