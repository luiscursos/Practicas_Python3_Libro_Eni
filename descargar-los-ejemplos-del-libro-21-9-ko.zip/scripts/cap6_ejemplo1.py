__author__ = 'febel'


def RepiteCar():
    for i in range(1, 21):
        print("*", end=" ")
    print(" ")


print("10 líneas de 20 caracteres")
for i in range(1, 11):
    RepiteCar()
