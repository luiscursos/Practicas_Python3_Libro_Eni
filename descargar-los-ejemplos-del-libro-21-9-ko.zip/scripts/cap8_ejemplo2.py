__author__ = 'febel'

def modif_int(var):
    var=10
    return var

v=0
modif_int(v)
print(v)
v=modif_int(v)
print(v)