__author__ = 'febel'
def repiteCar():
    for i in range(1,numcar+1):
        print(c,end=" ")
    print(" ")

global c
c='*'
for numcar in range(1,11):
    repiteCar()