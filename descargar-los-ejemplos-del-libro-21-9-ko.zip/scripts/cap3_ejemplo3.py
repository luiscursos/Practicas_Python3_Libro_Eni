__author__ = 'febel'
Cnt=int(input("¿Tabla?\n"))
resultado=Cnt
while Cnt>2:
    Cnt=Cnt-1
    resultado=resultado*Cnt
print(resultado)

